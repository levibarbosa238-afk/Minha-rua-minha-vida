exports.handler = async function () {
  const query = '[out:json][timeout:25];area["name"="Codó"]["boundary"="administrative"]->.codo;(way(area.codo)["highway"]["name"];);out tags;';
  const servers = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://overpass.private.coffee/api/interpreter'
  ];

  let lastError = 'Servidores de mapas indisponíveis.';
  for (const server of servers) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch(server, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
        body: 'data=' + encodeURIComponent(query),
        signal: controller.signal
      });
      if (!response.ok) throw new Error('Overpass respondeu com HTTP ' + response.status);
      const data = await response.json();
      const names = [...new Set((data.elements || [])
        .map(item => item.tags && item.tags.name)
        .filter(Boolean))].sort((a, b) => a.localeCompare(b, 'pt-BR'));
      if (!names.length) throw new Error('Nenhuma rua nomeada foi encontrada para Codó.');

      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'public, max-age=3600',
          'Netlify-CDN-Cache-Control': 'public, durable, max-age=86400, stale-while-revalidate=604800',
          'Netlify-Cache-Tag': 'ruas-codo'
        },
        body: JSON.stringify({ names, updatedAt: new Date().toISOString(), source: 'OpenStreetMap' })
      };
    } catch (error) {
      lastError = error && error.message ? error.message : lastError;
    } finally {
      clearTimeout(timeout);
    }
  }

  return {
    statusCode: 502,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
    body: JSON.stringify({ error: lastError })
  };
};
